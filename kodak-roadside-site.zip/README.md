# Kodak Roadside Assistance 24/7 — Landing Page

A simple, high-converting, SEO-friendly landing page for **Kodak, TN** roadside assistance.

## How to Use
1. Edit the phone number in `index.html` (find `tel:+18665551234` and update).
2. Commit to a GitHub repo.
3. Enable **GitHub Pages**: Settings → Pages → Source: `main` (or `master`) → `/root`.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.

## Google Business Profile (copy/paste)
**Description (<= 750 chars):**
Need fast roadside help in Kodak, TN? 🚗⚡ Kodak Roadside Assistance 24/7 provides quick, reliable service when you’re stranded. Whether you’re stuck on I-40, near Smokies Stadium, or at Bass Pro Shops, our local team arrives in 20–30 minutes on average. We offer towing, flat tire changes, jumpstarts, car lockout assistance, fuel delivery, and winch-outs at affordable prices. Proudly serving Kodak and surrounding areas including Sevierville, Pigeon Forge, and Gatlinburg. Available day or night, rain or shine. Call now and get back on the road fast with Kodak’s trusted roadside assistance team. 📞

## SEO Notes
- Title and H1 include **Kodak Roadside Assistance** (high-intent keyword).
- Local landmarks signal relevance to Kodak searches.
- Fast CTA buttons are click-to-call for mobile conversions.

## Files
- `index.html` — the full landing page (Tailwind via CDN).
- `robots.txt` — allow all.
- `sitemap.xml` — template; replace YOUR_DOMAIN with your real domain later.
